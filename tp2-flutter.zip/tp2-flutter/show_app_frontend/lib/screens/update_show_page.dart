// ✅ update_show_page.dart
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';
import 'package:show_app_frontend/config/api_config.dart';

class UpdateShowPage extends StatefulWidget {
  final Map<String, dynamic> show;

  const UpdateShowPage({super.key, required this.show});

  @override
  State<UpdateShowPage> createState() => _UpdateShowPageState();
}

class _UpdateShowPageState extends State<UpdateShowPage> {
  late TextEditingController _titleController;
  late TextEditingController _descriptionController;
  late String _selectedCategory;
  File? _newImage;
  bool _isUpdating = false;
  final picker = ImagePicker();

  @override
  void initState() {
    super.initState();
    _titleController = TextEditingController(text: widget.show['title']);
    _descriptionController = TextEditingController(text: widget.show['description']);
    _selectedCategory = widget.show['category'];
  }

  // Fonction pour choisir une image depuis la galerie
  Future<void> _pickImage() async {
    final XFile? image = await picker.pickImage(source: ImageSource.gallery);
    if (image != null) {
      setState(() {
        _newImage = File(image.path);
      });
    }
  }

  // Fonction pour envoyer la requête PUT au backend pour modifier un show
  Future<void> _updateShow() async {
    setState(() => _isUpdating = true);

    var uri = Uri.parse('${ApiConfig.baseUrl}/shows/${widget.show['id']}');
    var request = http.MultipartRequest('PUT', uri)
      ..fields['title'] = _titleController.text
      ..fields['description'] = _descriptionController.text
      ..fields['category'] = _selectedCategory;

    // Ajouter l'image si elle a été changée
    if (_newImage != null) {
      request.files.add(await http.MultipartFile.fromPath('image', _newImage!.path));
    }

    var response = await request.send();
    setState(() => _isUpdating = false);

    if (response.statusCode == 200) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Show updated!")));
      Navigator.pop(context, true); // Retour avec valeur true pour rafraîchir la liste
    } else {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Update failed.")));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Update Show"), backgroundColor: Colors.blueAccent),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: ListView(
          children: [
            // Champ de titre
            TextField(
              controller: _titleController,
              decoration: const InputDecoration(labelText: 'Title'),
            ),
            const SizedBox(height: 10),
            // Champ de description
            TextField(
              controller: _descriptionController,
              maxLines: 3,
              decoration: const InputDecoration(labelText: 'Description'),
            ),
            const SizedBox(height: 10),
            // Dropdown pour la catégorie
            DropdownButtonFormField<String>(
              value: _selectedCategory,
              items: const [
                DropdownMenuItem(value: 'movie', child: Text('Movie')),
                DropdownMenuItem(value: 'anime', child: Text('Anime')),
                DropdownMenuItem(value: 'serie', child: Text('Series')),
              ],
              onChanged: (value) => setState(() => _selectedCategory = value!),
              decoration: const InputDecoration(labelText: "Category"),
            ),
            const SizedBox(height: 10),
            // Affichage de l'image actuelle ou sélectionnée
            _newImage != null
                ? Image.file(_newImage!, height: 150)
                : widget.show['image'] != null
                    ? Image.network(ApiConfig.baseUrl + widget.show['image'], height: 150)
                    : const Text("No image"),
            const SizedBox(height: 10),
            // Bouton pour changer l'image
            ElevatedButton.icon(
              onPressed: _pickImage,
              icon: const Icon(Icons.image),
              label: const Text("Change Image"),
            ),
            const SizedBox(height: 20),
            // Bouton pour mettre à jour le show
            _isUpdating
                ? const Center(child: CircularProgressIndicator())
                : ElevatedButton(
                    onPressed: _updateShow,
                    style: ElevatedButton.styleFrom(backgroundColor: Colors.blueAccent),
                    child: const Text("Update Show", style: TextStyle(color: Colors.white)),
                  )
          ],
        ),
      ),
    );
  }
}
