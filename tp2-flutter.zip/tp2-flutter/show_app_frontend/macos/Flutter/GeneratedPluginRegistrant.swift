//
//  Generated file. Do not edit.
//

import FlutterMacOS
import Foundation

import file_selector_macos

func RegisterGeneratedPlugins(registry: FlutterPluginRegistry) {
  FileSelectorPlugin.register(with: registry.registrar(forPlugin: "FileSelectorPlugin"))
}
